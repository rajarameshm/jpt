package demo;

public interface HeapManagementMBean {
	
	public float getAmt();
	
	public void setAmt(float amt);

	 public void clear();
	 
	 
}
