
Contains in a linked list is proportional to the number of entries.

A HashSet will, on average, do the trick in constant time.