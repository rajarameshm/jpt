package ex02_aop.ex04_introductions;




public interface BeanInterface1
{

   public void setString(String val);
   
   public String getString();

   public int forceException(String val);

}
