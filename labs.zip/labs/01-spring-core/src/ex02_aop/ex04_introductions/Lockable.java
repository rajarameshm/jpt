
package ex02_aop.ex04_introductions;


public interface Lockable
{
   public void lock();
   
   public void unlock();
   
   public boolean locked();
   
}
