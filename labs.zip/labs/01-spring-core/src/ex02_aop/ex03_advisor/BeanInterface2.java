package ex02_aop.ex03_advisor;


public interface BeanInterface2
{

   public void setString(String val);
   
   public String getString();

   public int forceException(String val);

}
