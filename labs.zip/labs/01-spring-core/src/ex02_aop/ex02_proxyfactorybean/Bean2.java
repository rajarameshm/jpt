package ex02_aop.ex02_proxyfactorybean;



public class Bean2 extends Bean1 
{

}
