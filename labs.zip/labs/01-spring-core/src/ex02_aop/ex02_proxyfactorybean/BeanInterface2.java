package ex02_aop.ex02_proxyfactorybean;


public interface BeanInterface2
{

   public void setString(String val);
   
   public String getString();

   public int forceException(String val);
   
   public void disp();

}
