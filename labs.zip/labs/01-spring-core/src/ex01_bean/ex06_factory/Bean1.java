package ex01_bean.ex06_factory;


public class Bean1
{

   public Bean1(String val)
   {
      m_strVal = val;
   }
   
   public String getString()
   {
      return m_strVal;
   }
   
   private String m_strVal;

}
