package ex01_bean.ex02_setter;

import javax.annotation.PostConstruct;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class Account implements BeanNameAware,ApplicationContextAware,InitializingBean {

	
	public Account()
	{
		System.out.println("Lifecycle Step1...");
	}

	String beanName;
	float amt;
	ApplicationContext ctx;

	public float getAmt() {
		return amt;
	}

	public void setAmt(float amt) {
		System.out.println("Lifecycle Step2...DI");
		this.amt = amt;
	}

	public void setBeanName(String arg0) {
		// TODO Auto-generated method stub
		System.out.println("Lifecycle Step3...BN Aware");
		beanName=arg0;
	}

	public void setApplicationContext(ApplicationContext arg0) throws BeansException {
		// TODO Auto-generated method stub
		ctx=arg0;
		System.out.println("Lifecycle Step4...Application Context Aware");
	}
	
	@PostConstruct
	public void init()
	{
		System.out.println("Lifecycle Step6...@Postconstruct");
	}

	public void start()
	{
		System.out.println("Lifecycle Step8...Custom init method");
	}
	
	public void afterPropertiesSet() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("Lifecycle Step7...Initializing Bean");
		
	}
	
}
