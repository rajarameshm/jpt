package ex01_bean.ex02_setter;

public class Sample {

	String msg="sample message";
 
	public Sample()
	{
		System.out.println("Lifecycle1...sample class");
	}
	
	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	
}
